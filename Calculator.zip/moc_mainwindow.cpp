/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.10)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.10. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[93];
    char stringdata0[1745];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 20), // "on_calculate_clicked"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 7), // "setText"
QT_MOC_LITERAL(4, 41, 4), // "text"
QT_MOC_LITERAL(5, 46, 12), // "posIncrement"
QT_MOC_LITERAL(6, 59, 11), // "setTextProg"
QT_MOC_LITERAL(7, 71, 14), // "on_add_clicked"
QT_MOC_LITERAL(8, 86, 14), // "on_one_clicked"
QT_MOC_LITERAL(9, 101, 14), // "on_two_clicked"
QT_MOC_LITERAL(10, 116, 16), // "on_three_clicked"
QT_MOC_LITERAL(11, 133, 15), // "on_four_clicked"
QT_MOC_LITERAL(12, 149, 15), // "on_five_clicked"
QT_MOC_LITERAL(13, 165, 14), // "on_six_clicked"
QT_MOC_LITERAL(14, 180, 16), // "on_seven_clicked"
QT_MOC_LITERAL(15, 197, 16), // "on_eight_clicked"
QT_MOC_LITERAL(16, 214, 15), // "on_nine_clicked"
QT_MOC_LITERAL(17, 230, 15), // "on_zero_clicked"
QT_MOC_LITERAL(18, 246, 14), // "on_dot_clicked"
QT_MOC_LITERAL(19, 261, 19), // "on_multiply_clicked"
QT_MOC_LITERAL(20, 281, 16), // "on_minus_clicked"
QT_MOC_LITERAL(21, 298, 17), // "on_divide_clicked"
QT_MOC_LITERAL(22, 316, 21), // "on_percentage_clicked"
QT_MOC_LITERAL(23, 338, 16), // "on_clear_clicked"
QT_MOC_LITERAL(24, 355, 15), // "on_back_clicked"
QT_MOC_LITERAL(25, 371, 16), // "on_power_clicked"
QT_MOC_LITERAL(26, 388, 23), // "on_output_returnPressed"
QT_MOC_LITERAL(27, 412, 23), // "on_advancedMode_clicked"
QT_MOC_LITERAL(28, 436, 22), // "on_openBracket_clicked"
QT_MOC_LITERAL(29, 459, 23), // "on_closeBracket_clicked"
QT_MOC_LITERAL(30, 483, 21), // "on_piConstant_clicked"
QT_MOC_LITERAL(31, 505, 20), // "on_eConstant_clicked"
QT_MOC_LITERAL(32, 526, 21), // "on_reciprocal_clicked"
QT_MOC_LITERAL(33, 548, 15), // "on_root_clicked"
QT_MOC_LITERAL(34, 564, 14), // "on_sin_clicked"
QT_MOC_LITERAL(35, 579, 14), // "on_cos_clicked"
QT_MOC_LITERAL(36, 594, 14), // "on_tan_clicked"
QT_MOC_LITERAL(37, 609, 15), // "on_asin_clicked"
QT_MOC_LITERAL(38, 625, 15), // "on_acos_clicked"
QT_MOC_LITERAL(39, 641, 15), // "on_atan_clicked"
QT_MOC_LITERAL(40, 657, 13), // "on_ln_clicked"
QT_MOC_LITERAL(41, 671, 14), // "on_log_clicked"
QT_MOC_LITERAL(42, 686, 20), // "on_factorial_clicked"
QT_MOC_LITERAL(43, 707, 17), // "on_square_clicked"
QT_MOC_LITERAL(44, 725, 32), // "on_horizontalSlider_valueChanged"
QT_MOC_LITERAL(45, 758, 5), // "value"
QT_MOC_LITERAL(46, 764, 18), // "on_degrees_toggled"
QT_MOC_LITERAL(47, 783, 7), // "checked"
QT_MOC_LITERAL(48, 791, 18), // "on_radians_toggled"
QT_MOC_LITERAL(49, 810, 21), // "on_comboBox_activated"
QT_MOC_LITERAL(50, 832, 5), // "index"
QT_MOC_LITERAL(51, 838, 19), // "on_and_prog_clicked"
QT_MOC_LITERAL(52, 858, 18), // "on_or_prog_clicked"
QT_MOC_LITERAL(53, 877, 19), // "on_not_prog_clicked"
QT_MOC_LITERAL(54, 897, 20), // "on_nand_prog_clicked"
QT_MOC_LITERAL(55, 918, 19), // "on_nor_prog_clicked"
QT_MOC_LITERAL(56, 938, 20), // "on_exor_prog_clicked"
QT_MOC_LITERAL(57, 959, 17), // "on_a_prog_clicked"
QT_MOC_LITERAL(58, 977, 17), // "on_b_prog_clicked"
QT_MOC_LITERAL(59, 995, 17), // "on_c_prog_clicked"
QT_MOC_LITERAL(60, 1013, 17), // "on_d_prog_clicked"
QT_MOC_LITERAL(61, 1031, 17), // "on_e_prog_clicked"
QT_MOC_LITERAL(62, 1049, 17), // "on_f_prog_clicked"
QT_MOC_LITERAL(63, 1067, 21), // "on_clear_prog_clicked"
QT_MOC_LITERAL(64, 1089, 20), // "on_back_prog_clicked"
QT_MOC_LITERAL(65, 1110, 19), // "on_add_prog_clicked"
QT_MOC_LITERAL(66, 1130, 21), // "on_minus_prog_clicked"
QT_MOC_LITERAL(67, 1152, 24), // "on_multiply_prog_clicked"
QT_MOC_LITERAL(68, 1177, 22), // "on_divide_prog_clicked"
QT_MOC_LITERAL(69, 1200, 27), // "on_openBracket_prog_clicked"
QT_MOC_LITERAL(70, 1228, 28), // "on_closeBracket_prog_clicked"
QT_MOC_LITERAL(71, 1257, 26), // "on_left_shift_prog_clicked"
QT_MOC_LITERAL(72, 1284, 27), // "on_right_shift_prog_clicked"
QT_MOC_LITERAL(73, 1312, 19), // "on_one_prog_clicked"
QT_MOC_LITERAL(74, 1332, 19), // "on_two_prog_clicked"
QT_MOC_LITERAL(75, 1352, 21), // "on_three_prog_clicked"
QT_MOC_LITERAL(76, 1374, 20), // "on_four_prog_clicked"
QT_MOC_LITERAL(77, 1395, 20), // "on_five_prog_clicked"
QT_MOC_LITERAL(78, 1416, 19), // "on_six_prog_clicked"
QT_MOC_LITERAL(79, 1436, 21), // "on_seven_prog_clicked"
QT_MOC_LITERAL(80, 1458, 21), // "on_eight_prog_clicked"
QT_MOC_LITERAL(81, 1480, 20), // "on_nine_prog_clicked"
QT_MOC_LITERAL(82, 1501, 20), // "on_zero_prog_clicked"
QT_MOC_LITERAL(83, 1522, 23), // "on_n_complement_clicked"
QT_MOC_LITERAL(84, 1546, 25), // "on_n_complement_2_clicked"
QT_MOC_LITERAL(85, 1572, 25), // "on_calculate_prog_clicked"
QT_MOC_LITERAL(86, 1598, 22), // "on_hexEdit_textChanged"
QT_MOC_LITERAL(87, 1621, 4), // "arg1"
QT_MOC_LITERAL(88, 1626, 22), // "on_decEdit_textChanged"
QT_MOC_LITERAL(89, 1649, 22), // "on_octEdit_textChanged"
QT_MOC_LITERAL(90, 1672, 22), // "on_binEdit_textChanged"
QT_MOC_LITERAL(91, 1695, 14), // "on_mod_clicked"
QT_MOC_LITERAL(92, 1710, 34) // "on_horizontalSlider_2_valueCh..."

    },
    "MainWindow\0on_calculate_clicked\0\0"
    "setText\0text\0posIncrement\0setTextProg\0"
    "on_add_clicked\0on_one_clicked\0"
    "on_two_clicked\0on_three_clicked\0"
    "on_four_clicked\0on_five_clicked\0"
    "on_six_clicked\0on_seven_clicked\0"
    "on_eight_clicked\0on_nine_clicked\0"
    "on_zero_clicked\0on_dot_clicked\0"
    "on_multiply_clicked\0on_minus_clicked\0"
    "on_divide_clicked\0on_percentage_clicked\0"
    "on_clear_clicked\0on_back_clicked\0"
    "on_power_clicked\0on_output_returnPressed\0"
    "on_advancedMode_clicked\0on_openBracket_clicked\0"
    "on_closeBracket_clicked\0on_piConstant_clicked\0"
    "on_eConstant_clicked\0on_reciprocal_clicked\0"
    "on_root_clicked\0on_sin_clicked\0"
    "on_cos_clicked\0on_tan_clicked\0"
    "on_asin_clicked\0on_acos_clicked\0"
    "on_atan_clicked\0on_ln_clicked\0"
    "on_log_clicked\0on_factorial_clicked\0"
    "on_square_clicked\0on_horizontalSlider_valueChanged\0"
    "value\0on_degrees_toggled\0checked\0"
    "on_radians_toggled\0on_comboBox_activated\0"
    "index\0on_and_prog_clicked\0on_or_prog_clicked\0"
    "on_not_prog_clicked\0on_nand_prog_clicked\0"
    "on_nor_prog_clicked\0on_exor_prog_clicked\0"
    "on_a_prog_clicked\0on_b_prog_clicked\0"
    "on_c_prog_clicked\0on_d_prog_clicked\0"
    "on_e_prog_clicked\0on_f_prog_clicked\0"
    "on_clear_prog_clicked\0on_back_prog_clicked\0"
    "on_add_prog_clicked\0on_minus_prog_clicked\0"
    "on_multiply_prog_clicked\0"
    "on_divide_prog_clicked\0"
    "on_openBracket_prog_clicked\0"
    "on_closeBracket_prog_clicked\0"
    "on_left_shift_prog_clicked\0"
    "on_right_shift_prog_clicked\0"
    "on_one_prog_clicked\0on_two_prog_clicked\0"
    "on_three_prog_clicked\0on_four_prog_clicked\0"
    "on_five_prog_clicked\0on_six_prog_clicked\0"
    "on_seven_prog_clicked\0on_eight_prog_clicked\0"
    "on_nine_prog_clicked\0on_zero_prog_clicked\0"
    "on_n_complement_clicked\0"
    "on_n_complement_2_clicked\0"
    "on_calculate_prog_clicked\0"
    "on_hexEdit_textChanged\0arg1\0"
    "on_decEdit_textChanged\0on_octEdit_textChanged\0"
    "on_binEdit_textChanged\0on_mod_clicked\0"
    "on_horizontalSlider_2_valueChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      85,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  439,    2, 0x08 /* Private */,
       3,    2,  440,    2, 0x08 /* Private */,
       6,    2,  445,    2, 0x08 /* Private */,
       7,    0,  450,    2, 0x08 /* Private */,
       8,    0,  451,    2, 0x08 /* Private */,
       9,    0,  452,    2, 0x08 /* Private */,
      10,    0,  453,    2, 0x08 /* Private */,
      11,    0,  454,    2, 0x08 /* Private */,
      12,    0,  455,    2, 0x08 /* Private */,
      13,    0,  456,    2, 0x08 /* Private */,
      14,    0,  457,    2, 0x08 /* Private */,
      15,    0,  458,    2, 0x08 /* Private */,
      16,    0,  459,    2, 0x08 /* Private */,
      17,    0,  460,    2, 0x08 /* Private */,
      18,    0,  461,    2, 0x08 /* Private */,
      19,    0,  462,    2, 0x08 /* Private */,
      20,    0,  463,    2, 0x08 /* Private */,
      21,    0,  464,    2, 0x08 /* Private */,
      22,    0,  465,    2, 0x08 /* Private */,
      23,    0,  466,    2, 0x08 /* Private */,
      24,    0,  467,    2, 0x08 /* Private */,
      25,    0,  468,    2, 0x08 /* Private */,
      26,    0,  469,    2, 0x08 /* Private */,
      27,    0,  470,    2, 0x08 /* Private */,
      28,    0,  471,    2, 0x08 /* Private */,
      29,    0,  472,    2, 0x08 /* Private */,
      30,    0,  473,    2, 0x08 /* Private */,
      31,    0,  474,    2, 0x08 /* Private */,
      32,    0,  475,    2, 0x08 /* Private */,
      33,    0,  476,    2, 0x08 /* Private */,
      34,    0,  477,    2, 0x08 /* Private */,
      35,    0,  478,    2, 0x08 /* Private */,
      36,    0,  479,    2, 0x08 /* Private */,
      37,    0,  480,    2, 0x08 /* Private */,
      38,    0,  481,    2, 0x08 /* Private */,
      39,    0,  482,    2, 0x08 /* Private */,
      40,    0,  483,    2, 0x08 /* Private */,
      41,    0,  484,    2, 0x08 /* Private */,
      42,    0,  485,    2, 0x08 /* Private */,
      43,    0,  486,    2, 0x08 /* Private */,
      44,    1,  487,    2, 0x08 /* Private */,
      46,    1,  490,    2, 0x08 /* Private */,
      48,    1,  493,    2, 0x08 /* Private */,
      49,    1,  496,    2, 0x08 /* Private */,
      51,    0,  499,    2, 0x08 /* Private */,
      52,    0,  500,    2, 0x08 /* Private */,
      53,    0,  501,    2, 0x08 /* Private */,
      54,    0,  502,    2, 0x08 /* Private */,
      55,    0,  503,    2, 0x08 /* Private */,
      56,    0,  504,    2, 0x08 /* Private */,
      57,    0,  505,    2, 0x08 /* Private */,
      58,    0,  506,    2, 0x08 /* Private */,
      59,    0,  507,    2, 0x08 /* Private */,
      60,    0,  508,    2, 0x08 /* Private */,
      61,    0,  509,    2, 0x08 /* Private */,
      62,    0,  510,    2, 0x08 /* Private */,
      63,    0,  511,    2, 0x08 /* Private */,
      64,    0,  512,    2, 0x08 /* Private */,
      65,    0,  513,    2, 0x08 /* Private */,
      66,    0,  514,    2, 0x08 /* Private */,
      67,    0,  515,    2, 0x08 /* Private */,
      68,    0,  516,    2, 0x08 /* Private */,
      69,    0,  517,    2, 0x08 /* Private */,
      70,    0,  518,    2, 0x08 /* Private */,
      71,    0,  519,    2, 0x08 /* Private */,
      72,    0,  520,    2, 0x08 /* Private */,
      73,    0,  521,    2, 0x08 /* Private */,
      74,    0,  522,    2, 0x08 /* Private */,
      75,    0,  523,    2, 0x08 /* Private */,
      76,    0,  524,    2, 0x08 /* Private */,
      77,    0,  525,    2, 0x08 /* Private */,
      78,    0,  526,    2, 0x08 /* Private */,
      79,    0,  527,    2, 0x08 /* Private */,
      80,    0,  528,    2, 0x08 /* Private */,
      81,    0,  529,    2, 0x08 /* Private */,
      82,    0,  530,    2, 0x08 /* Private */,
      83,    0,  531,    2, 0x08 /* Private */,
      84,    0,  532,    2, 0x08 /* Private */,
      85,    0,  533,    2, 0x08 /* Private */,
      86,    1,  534,    2, 0x08 /* Private */,
      88,    1,  537,    2, 0x08 /* Private */,
      89,    1,  540,    2, 0x08 /* Private */,
      90,    1,  543,    2, 0x08 /* Private */,
      91,    0,  546,    2, 0x08 /* Private */,
      92,    1,  547,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    4,    5,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   45,
    QMetaType::Void, QMetaType::Bool,   47,
    QMetaType::Void, QMetaType::Bool,   47,
    QMetaType::Void, QMetaType::Int,   50,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   87,
    QMetaType::Void, QMetaType::QString,   87,
    QMetaType::Void, QMetaType::QString,   87,
    QMetaType::Void, QMetaType::QString,   87,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   45,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_calculate_clicked(); break;
        case 1: _t->setText((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 2: _t->setTextProg((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->on_add_clicked(); break;
        case 4: _t->on_one_clicked(); break;
        case 5: _t->on_two_clicked(); break;
        case 6: _t->on_three_clicked(); break;
        case 7: _t->on_four_clicked(); break;
        case 8: _t->on_five_clicked(); break;
        case 9: _t->on_six_clicked(); break;
        case 10: _t->on_seven_clicked(); break;
        case 11: _t->on_eight_clicked(); break;
        case 12: _t->on_nine_clicked(); break;
        case 13: _t->on_zero_clicked(); break;
        case 14: _t->on_dot_clicked(); break;
        case 15: _t->on_multiply_clicked(); break;
        case 16: _t->on_minus_clicked(); break;
        case 17: _t->on_divide_clicked(); break;
        case 18: _t->on_percentage_clicked(); break;
        case 19: _t->on_clear_clicked(); break;
        case 20: _t->on_back_clicked(); break;
        case 21: _t->on_power_clicked(); break;
        case 22: _t->on_output_returnPressed(); break;
        case 23: _t->on_advancedMode_clicked(); break;
        case 24: _t->on_openBracket_clicked(); break;
        case 25: _t->on_closeBracket_clicked(); break;
        case 26: _t->on_piConstant_clicked(); break;
        case 27: _t->on_eConstant_clicked(); break;
        case 28: _t->on_reciprocal_clicked(); break;
        case 29: _t->on_root_clicked(); break;
        case 30: _t->on_sin_clicked(); break;
        case 31: _t->on_cos_clicked(); break;
        case 32: _t->on_tan_clicked(); break;
        case 33: _t->on_asin_clicked(); break;
        case 34: _t->on_acos_clicked(); break;
        case 35: _t->on_atan_clicked(); break;
        case 36: _t->on_ln_clicked(); break;
        case 37: _t->on_log_clicked(); break;
        case 38: _t->on_factorial_clicked(); break;
        case 39: _t->on_square_clicked(); break;
        case 40: _t->on_horizontalSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 41: _t->on_degrees_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 42: _t->on_radians_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 43: _t->on_comboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 44: _t->on_and_prog_clicked(); break;
        case 45: _t->on_or_prog_clicked(); break;
        case 46: _t->on_not_prog_clicked(); break;
        case 47: _t->on_nand_prog_clicked(); break;
        case 48: _t->on_nor_prog_clicked(); break;
        case 49: _t->on_exor_prog_clicked(); break;
        case 50: _t->on_a_prog_clicked(); break;
        case 51: _t->on_b_prog_clicked(); break;
        case 52: _t->on_c_prog_clicked(); break;
        case 53: _t->on_d_prog_clicked(); break;
        case 54: _t->on_e_prog_clicked(); break;
        case 55: _t->on_f_prog_clicked(); break;
        case 56: _t->on_clear_prog_clicked(); break;
        case 57: _t->on_back_prog_clicked(); break;
        case 58: _t->on_add_prog_clicked(); break;
        case 59: _t->on_minus_prog_clicked(); break;
        case 60: _t->on_multiply_prog_clicked(); break;
        case 61: _t->on_divide_prog_clicked(); break;
        case 62: _t->on_openBracket_prog_clicked(); break;
        case 63: _t->on_closeBracket_prog_clicked(); break;
        case 64: _t->on_left_shift_prog_clicked(); break;
        case 65: _t->on_right_shift_prog_clicked(); break;
        case 66: _t->on_one_prog_clicked(); break;
        case 67: _t->on_two_prog_clicked(); break;
        case 68: _t->on_three_prog_clicked(); break;
        case 69: _t->on_four_prog_clicked(); break;
        case 70: _t->on_five_prog_clicked(); break;
        case 71: _t->on_six_prog_clicked(); break;
        case 72: _t->on_seven_prog_clicked(); break;
        case 73: _t->on_eight_prog_clicked(); break;
        case 74: _t->on_nine_prog_clicked(); break;
        case 75: _t->on_zero_prog_clicked(); break;
        case 76: _t->on_n_complement_clicked(); break;
        case 77: _t->on_n_complement_2_clicked(); break;
        case 78: _t->on_calculate_prog_clicked(); break;
        case 79: _t->on_hexEdit_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 80: _t->on_decEdit_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 81: _t->on_octEdit_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 82: _t->on_binEdit_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 83: _t->on_mod_clicked(); break;
        case 84: _t->on_horizontalSlider_2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 85)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 85;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 85)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 85;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
